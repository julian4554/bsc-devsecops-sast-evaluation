from flask import Flask, render_template
from api.auth import auth_bp
from api.patient import patient_bp
from api.search import search_bp
from api.appointments import appointments_bp
from api.stats import stats_bp
from api.fhir import fhir_bp
from config import Config  # <--- Wichtig: sicheres Config-Objekt


def create_app():
    # ----------------------------
    # Flask App erstellen
    # ----------------------------
    app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static"
    )

    # Sichere Konfiguration laden (DSGVO/BSI-konform)
    app.config.from_object(Config)

    # ----------------------------
    # Backend-API Blueprints
    # ----------------------------
    app.register_blueprint(auth_bp)
    app.register_blueprint(patient_bp)
    app.register_blueprint(search_bp)
    app.register_blueprint(appointments_bp)
    app.register_blueprint(stats_bp)
    app.register_blueprint(fhir_bp)

    # ----------------------------
    # Frontend Routes (UI)
    # ----------------------------

    @app.route("/")
    def login_page():
        return render_template("login.html")

    @app.route("/dashboard")
    def dashboard_page():
        return render_template("dashboard.html")

    @app.route("/patient/<int:patient_id>")
    def patient_page(patient_id):
        return render_template("patient.html", patient_id=patient_id)

    @app.route("/appointment")
    def appointment_page():
        return render_template("appointment.html")

    @app.route("/fhir_view/<int:patient_id>")
    def fhir_patient_view(patient_id):
        return render_template("fhir_viewer.html", patient_id=patient_id)

    return app


if __name__ == "__main__":
    # Debug defaultet zu False in Config – gut für Healthcare-Sicherheit
    app = create_app()
    app.run(debug=app.config["DEBUG"])

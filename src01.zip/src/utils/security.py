# src/utils/security.py
import base64
import hashlib
import hmac
import os
import secrets
from functools import wraps
from datetime import datetime, timedelta

from flask import request, jsonify, g, current_app
from database.db import fetch_one, execute


# -------------------------------------------------------
# Passwort-Hashing (PBKDF2) – DSGVO/BSI-konformer Standard
# -------------------------------------------------------

def hash_password(password: str) -> str:
    """
    Starkes Passwort-Hashing mit PBKDF2-HMAC-SHA256.
    - zufälliger Salt (16 Byte)
    - 200.000 Iterationen (BSI-Empfehlungsniveau)
    - Rückgabe: base64(salt + hash)
    """
    if not isinstance(password, str):
        raise ValueError("Password must be a string")

    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        200_000
    )
    return base64.b64encode(salt + dk).decode("ascii")


def verify_password(password: str, stored_hash: str) -> bool:
    """
    Verifiziert ein Passwort gegen einen gespeicherten PBKDF2-Hash.
    """
    try:
        raw = base64.b64decode(stored_hash.encode("ascii"))
    except Exception:
        return False

    if len(raw) < 32:
        return False

    salt = raw[:16]
    stored_dk = raw[16:]

    new_dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        200_000
    )

    return hmac.compare_digest(stored_dk, new_dk)


# -------------------------------------------------------
# Session-Handling – Token in DB (sessions-Tabelle)
# -------------------------------------------------------

def create_session(user_id: int) -> str:
    """
    Erstellt ein Session-Token, speichert es mit created_at und expires_at.
    """

    token = secrets.token_urlsafe(32)
    now = datetime.utcnow().isoformat()
    lifetime_minutes = current_app.config.get("SESSION_LIFETIME_MINUTES", 60)
    expires_at = (datetime.utcnow() + timedelta(minutes=lifetime_minutes)).isoformat()

    execute(
        """
        INSERT INTO sessions (user_id, token, created_at, expires_at)
        VALUES (?, ?, ?, ?)
        """,
        (user_id, token, now, expires_at)
    )

    return token


def _extract_token_from_request() -> str | None:
    """
    Liest das Session-Token aus dem Request:
    - bevorzugt Authorization: Bearer <token>
    - alternativ Cookie 'session_token'
    """
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        return auth_header.removeprefix("Bearer ").strip()

    cookie_token = request.cookies.get("session_token")
    if cookie_token:
        return cookie_token

    return None


def get_current_user():
    """
    Liefert den aktuell authentifizierten Benutzer anhand des Session-Tokens,
    oder None, falls:
    - kein Token
    - Session abgelaufen
    - Session ungültig
    """
    token = _extract_token_from_request()
    if not token:
        return None

    # Session + User laden
    row = fetch_one(
        """
        SELECT u.id, u.username, u.role, s.expires_at
        FROM sessions s
        JOIN users u ON u.id = s.user_id
        WHERE s.token = ?
        """,
        (token,)
    )
    if row is None:
        return None

    try:
        expires_at = datetime.fromisoformat(row["expires_at"])
    except Exception:
        return None

    if expires_at < datetime.utcnow():
        # Abgelaufene Session entfernen (Aufräumen)
        execute("DELETE FROM sessions WHERE token = ?", (token,))
        return None

    return {
        "id": row["id"],
        "username": row["username"],
        "role": row["role"]
    }


# -------------------------------------------------------
# Rollenbasierte Zugriffskontrolle (RBAC)
# -------------------------------------------------------

def require_role(allowed_roles: list[str]):
    """
    Decorator für Endpoints, die eine bestimmte Rolle erfordern.
    Beispiele:
        @require_role(["doctor", "nurse"])
        @require_role(["admin"])
    DSGVO/BSI:
        - Zugriff nur für berechtigte Personen (Need-to-know).
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = get_current_user()
            if user is None:
                return jsonify({"error": "Authentication required"}), 401

            if user["role"] not in allowed_roles:
                return jsonify({"error": "Forbidden"}), 403

            # Nutzer im Flask-Kontext bereitstellen
            g.current_user = user
            return fn(*args, **kwargs)
        return wrapper
    return decorator

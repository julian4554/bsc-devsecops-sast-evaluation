def validate_string(value: str, max_length: int = 100) -> bool:
    """
    Sicherheitsvalidierung für einfache Texteingaben.
    Phase A (SAFE):
    - Typprüfung
    - Strip
    - Maximale Länge
    """
    if not isinstance(value, str):
        return False

    value = value.strip()

    if len(value) == 0:
        return False

    if len(value) > max_length:
        return False

    return True

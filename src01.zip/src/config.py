# src/config.py
import os
from pathlib import Path

class Config:
    """
    Basis-Konfiguration für die Healthcare-Demo-Anwendung.
    Orientiert an DSGVO/BSI:
    - Geheimnisse nicht hardcodieren
    - sichere Session-Cookies
    - Debug in Produktion deaktiviert
    """

    # In Produktion immer per Umgebungsvariable setzen!
    SECRET_KEY = os.environ.get("SECRET_KEY", "CHANGE_ME_IN_PRODUCTION")

    # Session-Cookie-Härtung (BSI TR-03161-konform light)
    SESSION_COOKIE_SECURE = True      # nur über HTTPS senden
    SESSION_COOKIE_HTTPONLY = True    # nicht aus JavaScript lesbar
    SESSION_COOKIE_SAMESITE = "Lax"

    # Datenbankpfad zentralisiert
    BASE_DIR = Path(__file__).resolve().parent
    DATABASE_PATH = BASE_DIR / "healthcare.db"

    # Token-Gültigkeit in Minuten (Session-Timeout)
    SESSION_LIFETIME_MINUTES = int(os.environ.get("SESSION_LIFETIME_MINUTES", "60"))

    # Debug default: aus
    DEBUG = os.environ.get("FLASK_DEBUG", "0") == "1"

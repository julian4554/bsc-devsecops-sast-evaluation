import sqlite3
from pathlib import Path

# Path zur Datenbankdatei
DB_PATH = Path(__file__).resolve().parent.parent / "healthcare.db"

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # ermöglicht dict-artigen Zugriff
    return conn

def fetch_one(query, params=()):
    conn = get_connection()
    cursor = conn.execute(query, params)
    result = cursor.fetchone()
    conn.close()
    return result

def fetch_all(query, params=()):
    conn = get_connection()
    cursor = conn.execute(query, params)
    result = cursor.fetchall()
    conn.close()
    return result

def execute(query, params=()):
    conn = get_connection()
    cursor = conn.execute(query, params)
    conn.commit()
    conn.close()

INSERT INTO users (username, password, role)
VALUES
('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9
', 'admin'),
('doctor1', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'doctor'),
('admin1', 'admin1', 'nurse'),
('nurse1', '84b2278f8bf409fa095cbee2fd3564fbcd103ac167ba9bf20aa1522d43eadbd0', 'nurse');

INSERT INTO patients (first_name, last_name, diagnosis, birthdate, insurance_number)
VALUES
('John', 'Doe', 'Diabetes Type 2', '1980-03-15', 'A12345678'),
('Maria', 'Rossi', 'Hypertension', '1975-07-09', 'B98765432'),
('Ali', 'Yilmaz', 'Asthma', '1990-12-21', 'C11223344');

INSERT INTO appointments (patient_id, doctor_id, date, description)
VALUES
(1, 2, '2025-12-20 10:00', 'Routine check'),
(2, 2, '2025-12-21 14:00', 'Blood pressure review'),
(3, 3, '2025-12-22 09:30', 'Asthma follow-up');

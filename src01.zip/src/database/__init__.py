import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR.parent / "healthcare.db"

def init_db():
    print(f"[*] Creating database at: {DB_PATH}")

    # Existing DB delete
    if DB_PATH.exists():
        print("[*] Existing database removed.")
        DB_PATH.unlink()

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Load schema
    with open(BASE_DIR / "create_tables.sql", "r", encoding="utf-8") as f:
        cursor.executescript(f.read())

    # Load seed data
    with open(BASE_DIR / "seed_data.sql", "r", encoding="utf-8") as f:
        cursor.executescript(f.read())

    conn.commit()
    conn.close()
    print("[*] Database created and seeded successfully.")

if __name__ == "__main__":
    init_db()

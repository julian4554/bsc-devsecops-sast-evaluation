# create_secure_users.py

from utils.security import hash_password
from database.db import execute

# Sicher Benutzer anlegen
def create_user(username, password, role):
    hashed = hash_password(password)
    execute(
        "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
        (username, hashed, role)
    )
    print(f"Created user '{username}' with role '{role}'.")

# Standard-Healthcare-User
create_user("admin", "Admin123!", "admin")
create_user("doctor", "Doc123!", "doctor")
create_user("nurse", "Nurse123!", "nurse")

print("All users created successfully.")

from flask import Blueprint, request, jsonify, g
from database.db import fetch_all
from utils.security import require_role
from utils.logging_utils import audit_log
import sqlite3

search_bp = Blueprint("search", __name__)


@search_bp.route("/search", methods=["GET"])
@require_role(["doctor", "nurse"])
def search_patients():
    """
    Healthcare-SAFE Search Endpoint:
    --------------------------------
    - RBAC (doctor, nurse)
    - Audit Logging
    - MINIMUM NECESSARY (keine Diagnose!)
    - Parameterisierte SQL-Abfrage
    - FHIR-konformes Verhalten: Suche zeigt nur Basisdaten
    """

    query = request.args.get("q", "")

    # Input validation
    if not isinstance(query, str) or len(query.strip()) == 0:
        audit_log(g.current_user["id"], "SEARCH_PATIENTS", "Patient", None, success=False)
        return jsonify({"error": "Missing or invalid search query"}), 400

    if len(query) > 50:
        audit_log(g.current_user["id"], "SEARCH_PATIENTS", "Patient", None, success=False)
        return jsonify({"error": "Query too long"}), 400

    query = query.strip()

    try:
        # MINIMUM NECESSARY: Diagnose NICHT zurückgeben
        results = fetch_all(
            """
            SELECT id, first_name, last_name
            FROM patients
            WHERE first_name LIKE ? OR last_name LIKE ?
            """,
            (f"%{query}%", f"%{query}%")
        )
    except sqlite3.Error:
        audit_log(g.current_user["id"], "SEARCH_DB_ERROR", "Patient", None, success=False)
        return jsonify({"error": "Database error"}), 500

    audit_log(g.current_user["id"], "SEARCH_PATIENTS", "Patient", None, success=True)

    return jsonify({
        "query": query,
        "results": [
            {
                "id": r["id"],
                "first_name": r["first_name"],
                "last_name": r["last_name"]
            }
            for r in results
        ]
    }), 200

from flask import Blueprint, jsonify, g
from database.db import fetch_one
from utils.security import require_role
from utils.logging_utils import audit_log

stats_bp = Blueprint("stats", __name__)


@stats_bp.route("/stats", methods=["GET"])
@require_role(["admin"])
def get_stats():
    """
    Healthcare-SAFE Systemstatistik:
    --------------------------------
    - RBAC: Nur Admin darf Systemstatistiken sehen
    - Kein Leaken sensitiver Health-Informationen
    - Audit Logging aller Zugriffe
    - Minimum Necessary Output (keine PII)
    """

    try:
        # Anzahl Patienten
        patients_count = fetch_one("SELECT COUNT(*) AS count FROM patients")

        # Anzahl Benutzer
        users_count = fetch_one("SELECT COUNT(*) AS count FROM users")

        # Anzahl Termine
        appointments_count = fetch_one("SELECT COUNT(*) AS count FROM appointments")

        # Anzahl Ärzte
        doctors_count = fetch_one(
            "SELECT COUNT(*) AS count FROM users WHERE role = 'doctor'"
        )
    except Exception:
        audit_log(g.current_user["id"], "READ_STATS", "System", None, success=False)
        return jsonify({"error": "Database error"}), 500

    audit_log(g.current_user["id"], "READ_STATS", "System", None, success=True)

    return jsonify({
        "patients": patients_count["count"],
        "users": users_count["count"],
        "appointments": appointments_count["count"],
        "doctors": doctors_count["count"]
    }), 200

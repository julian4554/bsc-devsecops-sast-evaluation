from flask import Blueprint, request, jsonify, g
from database.db import fetch_one, execute
from utils.security import require_role
from utils.logging_utils import audit_log
import sqlite3

appointments_bp = Blueprint("appointments", __name__)


@appointments_bp.route("/appointments/create", methods=["POST"])
@require_role(["doctor", "nurse"])
def create_appointment():
    """
    Healthcare-SAFE Termin-Erstellung:
    ---------------------------------
    - RBAC: doctors & nurses
    - patient_id MUSS vom Client kommen
    - doctor_id DARF NICHT vom Client kommen! (DSGVO, FHIR Security!)
      -> Wir setzen doctor_id = g.current_user["id"]
    - Vollständiges Audit Logging
    - Parameterisierte SQL-Abfragen
    """

    data = request.get_json()

    # Pflichtfelder
    required_fields = ["patient_id", "date", "description"]
    if not data or not all(f in data for f in required_fields):
        audit_log(g.current_user["id"], "APPOINTMENT_CREATE", "Appointment", None, success=False)
        return jsonify({"error": "Missing fields: patient_id, date, description"}), 400

    patient_id = data["patient_id"]
    date = data["date"]
    description = data["description"]

    # doctor_id wird NICHT aus Client-Daten genommen!
    doctor_id = g.current_user["id"]

    # Input Validation
    if not isinstance(patient_id, int) or patient_id <= 0:
        audit_log(g.current_user["id"], "APPOINTMENT_CREATE", "Appointment", None, success=False)
        return jsonify({"error": "Invalid patient_id"}), 400

    if not isinstance(date, str) or len(date.strip()) == 0:
        audit_log(g.current_user["id"], "APPOINTMENT_CREATE", "Appointment", None, success=False)
        return jsonify({"error": "Invalid date"}), 400

    if not isinstance(description, str) or len(description.strip()) == 0:
        audit_log(g.current_user["id"], "APPOINTMENT_CREATE", "Appointment", None, success=False)
        return jsonify({"error": "Invalid description"}), 400

    # patient existiert?
    try:
        patient = fetch_one("SELECT id FROM patients WHERE id = ?", (patient_id,))
    except sqlite3.Error:
        return jsonify({"error": "Database error"}), 500

    if patient is None:
        audit_log(g.current_user["id"], "APPOINTMENT_CREATE", "Appointment", None, success=False)
        return jsonify({"error": "Patient not found"}), 404

    # Termin erstellen
    try:
        execute(
            """
            INSERT INTO appointments (patient_id, doctor_id, date, description)
            VALUES (?, ?, ?, ?)
            """,
            (patient_id, doctor_id, date.strip(), description.strip())
        )
    except sqlite3.Error:
        audit_log(g.current_user["id"], "APPOINTMENT_CREATE", "Appointment", None, success=False)
        return jsonify({"error": "Failed to create appointment"}), 500

    audit_log(g.current_user["id"], "APPOINTMENT_CREATE", "Appointment", patient_id, success=True)

    return jsonify({
        "message": "Appointment created",
        "patient_id": patient_id,
        "doctor_id": doctor_id,           # jetzt korrekt, NICHT client-gesteuert
        "date": date,
        "description": description
    }), 201

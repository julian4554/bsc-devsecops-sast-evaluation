from flask import Blueprint, request, jsonify, g
from database.db import fetch_one, execute
from utils.security import require_role
from utils.logging_utils import audit_log
import sqlite3

patient_bp = Blueprint("patient", __name__)


# -------------------------------------------------------
# GET /patient/<id>
# -------------------------------------------------------
@patient_bp.route("/patient/<int:patient_id>", methods=["GET"])
@require_role(["doctor", "nurse"])
def get_patient(patient_id):
    """
    Healthcare-SAFE Version:
    - RBAC (doctor, nurse)
    - Parameterisierte SQL-Abfrage
    - Audit Logging
    - Minimum Necessary / Reduced View für nurse
    """

    if patient_id <= 0:
        audit_log(None, "READ_PATIENT", "Patient", patient_id, success=False)
        return jsonify({"error": "Invalid patient ID"}), 400

    try:
        patient = fetch_one(
            """
            SELECT id, first_name, last_name, diagnosis, birthdate, insurance_number
            FROM patients
            WHERE id = ?
            """,
            (patient_id,)
        )
    except sqlite3.Error:
        audit_log(None, "READ_PATIENT", "Patient", patient_id, success=False)
        return jsonify({"error": "Database error"}), 500

    if patient is None:
        audit_log(g.current_user["id"], "READ_PATIENT", "Patient", patient_id, success=False)
        return jsonify({"error": "Patient not found"}), 404

    # RBAC basierte Datenreduktion
    if g.current_user["role"] == "nurse":
        response = {
            "id": patient["id"],
            "first_name": patient["first_name"],
            "last_name": patient["last_name"],
            "diagnosis": patient["diagnosis"],
            "birthdate": patient["birthdate"]
            # Keine Versicherungsnummer für nurse
        }
    else:
        # doctor sees everything
        response = {
            "id": patient["id"],
            "first_name": patient["first_name"],
            "last_name": patient["last_name"],
            "diagnosis": patient["diagnosis"],
            "birthdate": patient["birthdate"],
            "insurance_number": patient["insurance_number"]
        }

    audit_log(g.current_user["id"], "READ_PATIENT", "Patient", patient_id, success=True)
    return jsonify(response), 200


# -------------------------------------------------------
# POST /patient/update
# -------------------------------------------------------
@patient_bp.route("/patient/update", methods=["POST"])
@require_role(["doctor"])  # Nur Ärzte dürfen Diagnosen verändern
def update_patient():
    """
    Healthcare-SAFE Version:
    - doctor-only
    - Audit Logging
    - Parameterisierte SQL-Abfragen
    """

    data = request.get_json()

    if not data or "id" not in data or "diagnosis" not in data:
        audit_log(g.current_user["id"], "UPDATE_PATIENT_DIAGNOSIS", "Patient", None, success=False)
        return jsonify({"error": "Missing fields: id, diagnosis"}), 400

    patient_id = data["id"]
    new_diagnosis = data["diagnosis"]

    if not isinstance(patient_id, int) or patient_id <= 0:
        audit_log(g.current_user["id"], "UPDATE_PATIENT_DIAGNOSIS", "Patient", patient_id, success=False)
        return jsonify({"error": "Invalid patient ID"}), 400

    if not isinstance(new_diagnosis, str) or len(new_diagnosis.strip()) == 0:
        audit_log(g.current_user["id"], "UPDATE_PATIENT_DIAGNOSIS", "Patient", patient_id, success=False)
        return jsonify({"error": "Invalid diagnosis"}), 400

    try:
        patient = fetch_one("SELECT id FROM patients WHERE id = ?", (patient_id,))
    except sqlite3.Error:
        return jsonify({"error": "Database error"}), 500

    if patient is None:
        audit_log(g.current_user["id"], "UPDATE_PATIENT_DIAGNOSIS", "Patient", patient_id, success=False)
        return jsonify({"error": "Patient not found"}), 404

    try:
        execute(
            "UPDATE patients SET diagnosis = ? WHERE id = ?",
            (new_diagnosis.strip(), patient_id)
        )
    except sqlite3.Error:
        audit_log(g.current_user["id"], "UPDATE_PATIENT_DIAGNOSIS", "Patient", patient_id, success=False)
        return jsonify({"error": "Database update error"}), 500

    audit_log(g.current_user["id"], "UPDATE_PATIENT_DIAGNOSIS", "Patient", patient_id, success=True)

    return jsonify({
        "message": "Patient updated successfully",
        "patient_id": patient_id,
        "new_diagnosis": new_diagnosis
    }), 200

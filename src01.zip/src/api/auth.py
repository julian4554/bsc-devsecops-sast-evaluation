# src/api/auth.py (nur Funktion login anpassen)
from flask import Blueprint, request, jsonify
from database.db import fetch_one
from utils.security import verify_password, create_session
from utils.logging_utils import audit_log
import sqlite3

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["POST"])
def login():
    """
    Healthcare-SAFE Login Endpoint:
    - Parameterisierte Query auf users
    - PBKDF2-Hash-Überprüfung
    - Session-Token-Erstellung
    - Audit-Logging ohne sensible Daten
    """

    data = request.get_json(silent=True) or {}
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    try:
        user = fetch_one(
            "SELECT id, username, password, role FROM users WHERE username = ?",
            (username.strip(),)
        )
    except sqlite3.Error:
        # keine Details leaken
        return jsonify({"error": "Authentication failed"}), 401

    if user is None:
        # Benutzer existiert nicht → trotzdem generische Fehlermeldung
        audit_log(None, "LOGIN_FAILED_UNKNOWN_USER", "User", None, success=False)
        return jsonify({"error": "Authentication failed"}), 401

    if not verify_password(password, user["password"]):
        audit_log(user["id"], "LOGIN_FAILED_WRONG_PASSWORD", "User", user["id"], success=False)
        return jsonify({"error": "Authentication failed"}), 401

    token = create_session(user["id"])
    audit_log(user["id"], "LOGIN_SUCCESS", "User", user["id"], success=True)

    return jsonify({
        "message": "Login successful",
        "token": token,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "role": user["role"]
        }
    }), 200

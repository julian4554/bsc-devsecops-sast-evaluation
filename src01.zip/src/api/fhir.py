from flask import Blueprint, request, jsonify, g
from database.db import fetch_one, execute
from utils.security import require_role, get_current_user
from utils.logging_utils import audit_log
import json
import datetime

fhir_bp = Blueprint("fhir", __name__)


# -----------------------------------------------------------
# 1. VALIDATION FUNCTIONS (FHIR-STRUCTURAL + INPUT SAFETY)
# -----------------------------------------------------------

def validate_fhir_resource(resource_json, resource_type):
    """
    Prüft Minimalanforderungen nach FHIR R4.
    Für die Bachelorarbeit reichen Basiskriterien.
    """
    if not isinstance(resource_json, dict):
        return False

    if resource_json.get("resourceType") != resource_type:
        return False

    # Minimale Pflichtfelder für Patient
    if resource_type == "Patient":
        if "name" not in resource_json:
            return False
        if "birthDate" not in resource_json:
            return False

    # Optional: IG-Profile / CodeSystems prüfen
    # (für die Bachelorarbeit reicht Basiskonformität)

    return True


def sanitize_fhir_input(resource_json):
    """
    Sanitized Freitext-Eingaben (FHIR erlaubt Freitext bei Notes/Comments).
    Protective measure gegen Injection und Script Tags.
    """
    dangerous_keys = ["note", "comment", "text"]

    for key in dangerous_keys:
        if key in resource_json:
            val = resource_json[key]
            if isinstance(val, str):
                resource_json[key] = val.replace("<", "").replace(">", "")

    return resource_json


# -----------------------------------------------------------
# 2. SCOPE + LEGAL BASIS CHECKING (FHIR SECURITY)
# -----------------------------------------------------------

def check_fhir_scope(user, required_scope):
    """
    Simplifizierte Scope-Prüfung (SMART-on-FHIR-light).
    In echten Systemen wäre dies OAuth2 + Scopes in JWT.
    """

    # Für Phase A: doctor = full access, nurse = reduced access
    role = user["role"]

    if required_scope == "patient.read":
        return role in ["doctor", "nurse"]

    if required_scope == "patient.write":
        return role in ["doctor"]

    # default deny
    return False


def check_legal_basis(user_role, resource_type):
    """
    DSGVO-Kompatibilität: Need-to-know
    """
    if resource_type == "Patient" and user_role in ["doctor", "nurse"]:
        return True

    if resource_type == "Patient" and user_role == "admin":
        return False  # Admin darf keine Diagnosedaten sehen

    return False


# -----------------------------------------------------------
# 3. AUDIT EVENT CREATION (FHIR AuditEvent)
# -----------------------------------------------------------

def create_audit_event(action, resource_type, resource_id, success=True):
    """
    Erzeugt ein AuditEvent nach FHIR R4.
    (Für die Arbeit reichen Basiseinträge.)
    """
    event = {
        "resourceType": "AuditEvent",
        "type": {"code": "rest"},
        "action": action,
        "recorded": datetime.datetime.utcnow().isoformat(),
        "source": {"site": "Healthcare API"},
        "agent": [{
            "userId": g.current_user["id"],
            "requestor": True,
            "role": [{"code": g.current_user["role"]}]
        }],
        "entity": [{
            "what": {
                "reference": f"{resource_type}/{resource_id}"
            }
        }],
        "outcome": "0" if success else "4"
    }

    # Write into audit_logs table
    audit_log(g.current_user["id"], f"FHIR_{action}", resource_type, resource_id, success)

    return event


# -----------------------------------------------------------
# 4. FHIR ENDPOINTS
# -----------------------------------------------------------

@fhir_bp.route("/fhir/Patient/<int:patient_id>", methods=["GET"])
@require_role(["doctor", "nurse"])
def get_fhir_patient(patient_id):
    user = g.current_user

    # Scope Enforcement
    if not check_fhir_scope(user, "patient.read"):
        return jsonify({"error": "Insufficient scope"}), 403

    # Legal basis (Need-to-know)
    if not check_legal_basis(user["role"], "Patient"):
        return jsonify({"error": "Not permitted"}), 403

    # Fetch internal patient
    patient = fetch_one("""
        SELECT id, first_name, last_name, birthdate, insurance_number
        FROM patients WHERE id = ?
    """, (patient_id,))

    if not patient:
        create_audit_event("read", "Patient", patient_id, False)
        return jsonify({"error": "Patient not found"}), 404

    # Build FHIR Patient Resource
    fhir_patient = {
        "resourceType": "Patient",
        "id": str(patient["id"]),
        "name": [{"family": patient["last_name"], "given": [patient["first_name"]]}],
        "birthDate": patient["birthdate"],
        "identifier": [{
            "system": "https://example.org/fhir/insurance",
            "value": patient["insurance_number"]
        }],
        "meta": {
            "security": [{
                "system": "http://hl7.org/fhir/v3/Confidentiality",
                "code": "N",
                "display": "normal"
            }]
        }
    }

    create_audit_event("read", "Patient", patient_id, True)

    return jsonify(fhir_patient), 200

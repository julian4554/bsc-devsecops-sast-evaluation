// Load patient details on page load
window.onload = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
        window.location.href = "/";
        return;
    }

    const res = await fetch(`/patient/${PATIENT_ID}`, {
        headers: { "Authorization": "Bearer " + token }
    });

    const data = await res.json();

    if (!res.ok) {
        document.getElementById("message").textContent = data.error || "Failed to load patient.";
        return;
    }

    // SAFE (Phase A) – textContent statt innerHTML
    document.getElementById("name").textContent = data.first_name + " " + data.last_name;
    document.getElementById("diagnosis").textContent = data.diagnosis;
    document.getElementById("birthdate").textContent = data.birthdate;
    document.getElementById("insurance").textContent = data.insurance_number;
};


async function updateDiagnosis() {
    const token = localStorage.getItem("token");
    const diagnosis = document.getElementById("newDiagnosis").value.trim();

    if (diagnosis.length === 0) {
        document.getElementById("message").textContent = "Diagnosis cannot be empty.";
        return;
    }

    const res = await fetch("/patient/update", {
        method: "POST",
        headers: {
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            id: PATIENT_ID,
            diagnosis: diagnosis
        })
    });

    const data = await res.json();

    if (res.ok) {
        document.getElementById("diagnosis").textContent = diagnosis;
        document.getElementById("message").textContent = "Updated successfully!";
    } else {
        document.getElementById("message").textContent = data.error;
    }
}


function goBack() {
    window.location.href = "/dashboard";
}

function openFHIR() {
    window.location.href = `/fhir_view/${PATIENT_ID}`;
}

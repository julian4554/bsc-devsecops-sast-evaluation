document.getElementById("loginForm").onsubmit = async (e) => {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const msg = document.getElementById("message");

    // Eingabeprüfung
    if (username.length === 0 || password.length === 0) {
        msg.textContent = "Please enter both username and password.";
        return;
    }

    try {
        const res = await fetch("/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ username, password })
        });

        const data = await res.json();

        if (res.ok) {
            // Token speichern
            localStorage.setItem("token", data.token);

            // Weiterleitung zum Dashboard
            window.location.href = "/dashboard";
        } else {
            // SAFE: KEIN innerHTML -> verhindert XSS
            msg.textContent = data.error || "Login failed";
        }

    } catch (err) {
        msg.textContent = "Network error.";
    }
};

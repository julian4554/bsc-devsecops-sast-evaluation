window.onload = async () => {
    const token = localStorage.getItem("token");
    const output = document.getElementById("fhirOutput");
    const msg = document.getElementById("message");

    if (!token) {
        window.location.href = "/";
        return;
    }

    try {
        const res = await fetch(`/fhir/Patient/${PATIENT_ID}`, {
            headers: {
                "Authorization": "Bearer " + token
            }
        });

        const data = await res.json();

        if (res.ok) {
            // SAFE (Phase A): Use textContent (never innerHTML)
            output.textContent = JSON.stringify(data, null, 4);
        } else {
            msg.textContent = data.error || "Failed to load FHIR resource.";
            output.textContent = "";
        }

    } catch (err) {
        msg.textContent = "Network error.";
        output.textContent = "";
    }
};

function goBack() {
    window.location.href = `/patient/${PATIENT_ID}`;
}
